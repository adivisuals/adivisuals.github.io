import type { Page } from "@/App";
import { site } from "@/data/content";
import { useInView } from "@/hooks/useInView";
import SocialIcons from "@/components/SocialIcons";
import heroBg from "@/assets/hero-bg.jpg";

interface AboutPageProps {
  navigate: (page: Page) => void;
}

const approach = [
  {
    num: "01",
    title: "Understand",
    body: "Every edit starts with the story. I dig into your message, audience and goals before touching a timeline.",
  },
  {
    num: "02",
    title: "Craft",
    body: "Pacing, sound design, color and motion are tuned to keep viewers locked in from the first frame to the last.",
  },
  {
    num: "03",
    title: "Deliver",
    body: "Polished, platform-ready exports delivered on time — and revisions until it feels exactly right.",
  },
];

const stats = (s: typeof site.stats) => [
  { value: s.videos, label: "Videos" },
  { value: s.views, label: "Views" },
  { value: s.likes, label: "Likes" },
];

export default function AboutPage({ navigate }: AboutPageProps) {
  const bioSection = useInView<HTMLDivElement>();
  const processSection = useInView<HTMLDivElement>();
  const ctaSection = useInView<HTMLDivElement>();
  const numbers = stats(site.stats);

  return (
    <div className="bg-black min-h-screen">
      {/* Hero */}
      <section
        className="relative min-h-[60vh] flex items-end pt-16 overflow-hidden"
        style={{
          backgroundImage: `url(${heroBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center 35%",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        <div className="relative z-10 px-8 md:px-16 pb-16 max-w-6xl">
          <div className="flex items-center gap-3 mb-5 animate-fade-in-up">
            <div className="w-8 h-px bg-amber-400/60" />
            <p
              className="text-amber-400 text-xs tracking-[0.4em] uppercase"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              About Me
            </p>
          </div>
          <h1
            className="animate-fade-in-up delay-100 text-[clamp(3.5rem,12vw,9rem)] leading-[0.88] tracking-tight text-[#f5f0e8]"
            style={{ fontFamily: "'Bebas Neue', cursive" }}
          >
            The
            <span className="text-transparent" style={{ WebkitTextStroke: "2px rgba(245,240,232,0.5)" }}>
              &nbsp;Editor
            </span>
          </h1>
        </div>
      </section>

      {/* Bio */}
      <section className="py-24 bg-black" ref={bioSection.ref}>
        <div className="max-w-5xl mx-auto px-6 grid md:grid-cols-5 gap-12 items-start">
          <div
            className={`md:col-span-3 transition-all duration-800 ${
              bioSection.inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
          >
            <p className="text-gray-400 text-base leading-[1.9] font-light">
              I'm <span className="text-amber-400">Aditya Vishwakarma</span> — a video editor obsessed with
              turning raw footage into stories people can't scroll past. From punchy commentary cuts to
              cinematic documentaries, I live in the details: the beat of a transition, the warmth of a grade,
              the silence before a punchline.
            </p>
            <p className="text-gray-500 text-sm leading-[1.9] mt-6 font-light">
              What started as curiosity became a craft. Today I work across business, tech, gaming and
              documentary content — always chasing that perfect cut. No project is too small; I bring the
              same energy to a 30-second reel as I do to a 20-minute film.
            </p>
            <p
              className="text-gray-600 text-xs tracking-[0.3em] uppercase mt-10 italic"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              "Always giving 100%."
            </p>
          </div>

          <div
            className={`md:col-span-2 transition-all delay-200 duration-800 ${
              bioSection.inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
            }`}
          >
            <div className="border border-white/8 bg-zinc-950/60 p-8">
              <p
                className="text-amber-400 text-xs tracking-[0.4em] uppercase mb-6"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                By the Numbers
              </p>
              <div className="grid grid-cols-3 gap-4 text-center">
                {numbers.map(({ value, label }) => (
                  <div key={label}>
                    <span
                      className="block text-3xl text-[#f5f0e8] leading-none"
                      style={{ fontFamily: "'Bebas Neue', cursive" }}
                    >
                      {value}
                    </span>
                    <span className="text-gray-600 text-[10px] tracking-[0.2em] uppercase mt-2 block">
                      {label}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-white/5">
                <p className="text-gray-600 text-[10px] tracking-[0.3em] uppercase mb-4">Find Me</p>
                <SocialIcons />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-24 bg-zinc-950" ref={processSection.ref}>
        <div className="max-w-5xl mx-auto px-6">
          <div
            className={`flex flex-col items-center mb-16 transition-all duration-700 ${
              processSection.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px bg-amber-400/50" />
              <p
                className="text-amber-400 text-xs tracking-[0.4em] uppercase"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                How I Work
              </p>
              <div className="w-8 h-px bg-amber-400/50" />
            </div>
            <h2
              className="text-center text-[clamp(2.5rem,7vw,6rem)] text-[#f5f0e8] leading-none"
              style={{ fontFamily: "'Bebas Neue', cursive" }}
            >
              The Process
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {approach.map(({ num, title, body }, i) => (
              <div
                key={num}
                className={`border border-white/8 p-8 bg-black/40 hover:border-amber-400/30 transition-all duration-500 ${
                  processSection.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{
                  transitionDelay: processSection.inView ? `${i * 100}ms` : "0ms",
                }}
              >
                <span
                  className="block text-amber-400/40 text-4xl mb-4"
                  style={{ fontFamily: "'Bebas Neue', cursive" }}
                >
                  {num}
                </span>
                <h3
                  className="text-[#f5f0e8] text-2xl mb-3"
                  style={{ fontFamily: "'Bebas Neue', cursive", letterSpacing: "0.08em" }}
                >
                  {title}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed font-light">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-black text-center" ref={ctaSection.ref}>
        <div
          className={`max-w-2xl mx-auto px-6 transition-all duration-800 ${
            ctaSection.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2
            className="text-[clamp(2.5rem,7vw,5rem)] text-[#f5f0e8] mb-6 leading-none"
            style={{ fontFamily: "'Bebas Neue', cursive" }}
          >
            Let's Tell Your Story
          </h2>
          <p className="text-gray-500 text-sm leading-relaxed mb-10 max-w-md mx-auto">
            Got footage that deserves more? Let's turn it into something unforgettable.
          </p>
          <button
            onClick={() => navigate("contact")}
            className="px-10 py-4 bg-amber-400 text-black text-xs tracking-widest uppercase font-semibold hover:bg-amber-300 transition-colors duration-300"
          >
            Get In Touch
          </button>
        </div>
      </section>
    </div>
  );
}
